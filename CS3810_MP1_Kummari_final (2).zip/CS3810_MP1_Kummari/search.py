

import math

from priority_queue import PriorityQueue

# Sentinel used by the IDA* recursion to report success. Returning a plain
# number means "the smallest f-value I saw above the threshold".
FOUND = 'FOUND'


def dfs_search(problem):
    """
    Perform Depth-First Search.

    Args:
        problem: VacuumWorld instance

    Returns:
        Tuple (solution_path, nodes_expanded, max_frontier_size)
        solution_path: List of actions, or None if no solution
        nodes_expanded: Number of nodes expanded during search
        max_frontier_size: Maximum size of frontier during search

    Requirements:
        * Iterative, with an explicit stack. Do NOT recurse - you will hit
          Python's recursion limit on the larger grids.
        * Cycle detection with an explored set, or DFS will not terminate.
        * Returns the FIRST solution found. It will not be optimal, and it
          is not supposed to be.

    Hint: push (state, path_so_far) pairs. Push successors in reversed()
    order if you want the stack to explore them in ACTION_ORDER order.
    """
    start = problem.initial_state()
    frontier = [(start, [])]
    explored = set()
    discovered = {start}
    expanded = 0
    max_frontier = 1
    while frontier:
        state, path = frontier.pop()
        if problem.is_goal(state):
            return path, expanded, max_frontier
        if state in explored:
            continue
        explored.add(state)
        expanded += 1
        # Reverse push order so the first canonical action is explored first.
        for action in reversed(problem.get_actions(state)):
            child = problem.result(state, action)
            if child not in discovered:
                discovered.add(child)
                frontier.append((child, path + [action]))
        max_frontier = max(max_frontier, len(frontier))
    return None, expanded, max_frontier


def astar_search(problem, heuristic):
    """
    Perform A* Search.

    Args:
        problem: VacuumWorld instance
        heuristic: Function h(state, problem) -> estimated cost to goal

    Returns:
        Tuple (solution_path, nodes_expanded, max_frontier_size)

    Requirements:
        * Priority queue ordered by f(n) = g(n) + h(n).
        * Handle REOPENING: if you find a cheaper path to a state you have
          already expanded, you must be able to improve it. The provided
          PriorityQueue supports this - pushing an item already in the
          queue replaces its priority instead of duplicating it.
        * With an admissible heuristic this MUST return an optimal
          solution. run_tests.py checks that against known optimal costs.

    Hint: keep a dict g[state] of best-known cost-so-far and a dict
    came_from[state] = (parent_state, action) to rebuild the path at the
    end. A helper like _reconstruct() below keeps the main loop readable.
    """
    start = problem.initial_state()
    frontier = PriorityQueue()
    frontier.push(start, heuristic(start, problem))
    g_score = {start: 0}
    came_from = {}
    expanded = 0
    max_frontier = 1
    while frontier:
        state = frontier.pop()
        if problem.is_goal(state):
            return _reconstruct(came_from, state), expanded, max_frontier
        expanded += 1
        for action in problem.get_actions(state):
            child = problem.result(state, action)
            candidate = g_score[state] + problem.action_cost(state, action)
            if candidate < g_score.get(child, math.inf):
                g_score[child] = candidate
                came_from[child] = (state, action)
                frontier.push(child, candidate + heuristic(child, problem))
        max_frontier = max(max_frontier, len(frontier))
    return None, expanded, max_frontier


def _reconstruct(came_from, state):
    """Walk came_from backwards from `state` and return the action list.

    Args:
        came_from: Dict mapping state -> (parent_state, action)
        state: The goal state reached by the search

    Returns:
        List of actions from the initial state to `state`.
    """
    actions = []
    while state in came_from:
        state, action = came_from[state]
        actions.append(action)
    return list(reversed(actions))


def idastar_search(problem, heuristic):
    """
    Perform Iterative Deepening A* Search.

    Args:
        problem: VacuumWorld instance
        heuristic: Function h(state, problem) -> estimated cost to goal

    Returns:
        Tuple (solution_path, nodes_expanded, iterations)
        iterations: Number of depth-limited iterations performed

    Requirements:
        * Iterative deepening on an f-cost THRESHOLD, not on depth. The
          next threshold is the smallest f-value that exceeded the current
          one.
        * Linear space: no explored set carried across iterations. You may
          track the states on the current path to avoid immediate cycles.
        * Returns an optimal solution.

    Structure that works (write DFS and A* first - this will make far more
    sense once you have both):

        threshold = h(start)
        loop:
            result = search(start, g=0, threshold)
            if result is FOUND:    return the path
            if result is infinite: return None (no solution)
            threshold = result

    where search(state, g, threshold) returns FOUND, or the smallest
    f-value it saw that exceeded the threshold, or math.inf.
    """
    start = problem.initial_state()
    threshold = heuristic(start, problem)
    iterations = 0
    expanded = 0
    path = []
    on_path = {start}

    def visit(state, g, bound):
        nonlocal expanded
        estimate = g + heuristic(state, problem)
        if estimate > bound:
            return estimate
        if problem.is_goal(state):
            return FOUND
        expanded += 1
        smallest_excess = math.inf
        for action in problem.get_actions(state):
            child = problem.result(state, action)
            if child in on_path:
                continue
            on_path.add(child)
            path.append(action)
            result = visit(child, g + problem.action_cost(state, action), bound)
            if result == FOUND:
                return FOUND
            smallest_excess = min(smallest_excess, result)
            path.pop()
            on_path.remove(child)
        return smallest_excess

    while True:
        iterations += 1
        result = visit(start, 0, threshold)
        if result == FOUND:
            return list(path), expanded, iterations
        if result == math.inf:
            return None, expanded, iterations
        threshold = result


if __name__ == "__main__":
    # Quick manual check once you have implemented an algorithm:
    from test_grids import EXAMPLE, parse_grid
    from vacuum_world import VacuumWorld
    from heuristics import h2

    grid, start, dirty = parse_grid(EXAMPLE)
    problem = VacuumWorld(grid, start, dirty)

    path, expanded, frontier = astar_search(problem, h2)
    print("A* on the example grid (optimal cost is 14)")
    print("  cost     :", len(path) if path else None)
    print("  expanded :", expanded)
    print("  frontier :", frontier)
    print("  plan     :", path)
