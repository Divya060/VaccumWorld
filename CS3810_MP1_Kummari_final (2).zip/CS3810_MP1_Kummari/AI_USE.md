# AI assistance disclosure

Tool: OpenAI ChatGPT (GPT-6), November 12, 2026.

Used chatgpt to understand the project
