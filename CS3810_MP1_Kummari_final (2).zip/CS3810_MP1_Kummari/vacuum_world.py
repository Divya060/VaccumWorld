

# The canonical action order. Filter this list; do not reorder it.
ACTION_ORDER = ['MOVE_UP', 'MOVE_DOWN', 'MOVE_LEFT', 'MOVE_RIGHT', 'CLEAN']

# Row/column offsets for the four movement actions.
DELTAS = {
    'MOVE_UP': (-1, 0),
    'MOVE_DOWN': (1, 0),
    'MOVE_LEFT': (0, -1),
    'MOVE_RIGHT': (0, 1),
}


class VacuumWorld:
    """A vacuum-cleaning robot problem on a rectangular grid."""

    def __init__(self, grid, start, dirty):
        """
        Args:
            grid:  List of strings or list of lists; '#' marks an obstacle.
            start: Tuple (row, col) - the robot's starting position.
            dirty: Iterable of (row, col) tuples that begin dirty.

        Suggested attributes to set here: self.grid, self.rows, self.cols,
        self.start, self.dirty.
        """
        self.grid = tuple(tuple(row) for row in grid)
        self.rows = len(self.grid)
        self.cols = len(self.grid[0]) if self.rows else 0
        if not self.rows or not self.cols or any(len(row) != self.cols for row in self.grid):
            raise ValueError("Grid must be nonempty and rectangular")
        self.start = tuple(start)
        self.dirty = frozenset(tuple(cell) for cell in dirty)
        if not self.is_passable(self.start) or any(not self.is_passable(cell) for cell in self.dirty):
            raise ValueError("Start and dirt must occupy passable cells")

    # -- helpers ---------------------------------------------------------
    # These two are not graded directly and not called by the test harness,
    # but get_actions() and result() are much shorter if you write them.

    def in_bounds(self, pos):
        """Return True if pos is inside the grid."""
        return 0 <= pos[0] < self.rows and 0 <= pos[1] < self.cols

    def is_passable(self, pos):
        """Return True if pos is in bounds and is not an obstacle."""
        return self.in_bounds(pos) and self.grid[pos[0]][pos[1]] != "#"

    # -- problem interface -----------------------------------------------

    def initial_state(self):
        """Return the initial state as ((row, col), frozenset(dirty))."""
        return (self.start, self.dirty)

    def is_goal(self, state):
        """Return True if the dirty set in `state` is empty."""
        return not state[1]

    def get_actions(self, state):
        """Return a list of legal action names available in `state`.

        Legal means: moves stay in bounds and off obstacles, and CLEAN is
        only offered when the robot's current cell is dirty. Return the
        actions in ACTION_ORDER order.
        """
        position, dirty = state
        legal = []
        for action in ACTION_ORDER:
            if action == "CLEAN":
                if position in dirty:
                    legal.append(action)
            else:
                dr, dc = DELTAS[action]
                if self.is_passable((position[0] + dr, position[1] + dc)):
                    legal.append(action)
        return legal

    def result(self, state, action):
        """Return the successor state produced by applying `action`.

        Must not modify `state`.
        """
        if action not in self.get_actions(state):
            raise ValueError("Illegal action: " + str(action))
        position, dirty = state
        if action == "CLEAN":
            return (position, dirty - {position})
        dr, dc = DELTAS[action]
        return ((position[0] + dr, position[1] + dc), dirty)

    def action_cost(self, state, action):
        """Return the cost of `action` in `state` (always 1 here)."""
        return 1

    # -- debugging -------------------------------------------------------

    def render(self, state=None):
        """Return a printable picture of `state` (defaults to the initial state).

        Use the same characters as test_grids.py: '#' obstacle, 'R' robot,
        'D' dirty, '*' robot on a dirty cell, '.' clean and empty.

        This is not graded for correctness, but you will use it constantly
        while debugging. Write it first.
        """
        position, dirty = self.initial_state() if state is None else state
        lines = []
        for r in range(self.rows):
            line = []
            for c in range(self.cols):
                cell = (r, c)
                symbol = "#" if not self.is_passable(cell) else "."
                if cell in dirty:
                    symbol = "D"
                if cell == position:
                    symbol = "*" if cell in dirty else "R"
                line.append(symbol)
            lines.append(" ".join(line))
        return "\n".join(lines)

    def __str__(self):
        return self.render()


if __name__ == "__main__":
    # Quick manual check once you have implemented the class:
    from test_grids import EXAMPLE, parse_grid

    grid, start, dirty = parse_grid(EXAMPLE)
    problem = VacuumWorld(grid, start, dirty)
    print(problem.render())
    print("initial state:", problem.initial_state())
    print("legal actions:", problem.get_actions(problem.initial_state()))
