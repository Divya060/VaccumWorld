# CS 5550 / CS3810 Mini Project 1 — Vacuum World

Requires Python 3.10+; matplotlib is required for figures. The core algorithms use only the Python standard library.

1. `python run_tests.py` — verify the provided smoke tests.
2. `python experiments.py --timeout 60 --analyze` — rerun all six grids at the handout’s required 60-second timeout; writes `results.csv`, `summary.csv`, and `figures/`.
3. `python experiments.py --quick --timeout 60 --analyze` — quick diagnostic only.

The included `results.csv`, `summary.csv`, and `figures/` come from the full 60-second-per-configuration sweep (step 2). Four configurations hit the 60-second timeout: IDA* with h0 on g5_rooms, and IDA* with h0, h1, and h2 on g6_corridor. `summary.csv` is one row per grid with nodes expanded for each algorithm/heuristic.

`dfs_search` returns path, expanded nodes, and maximum frontier; `astar_search` returns the same; `idastar_search` returns path, expanded nodes, and threshold iterations. Nodes expanded excludes goal checks that do not generate successors. The deterministic action order is UP, DOWN, LEFT, RIGHT, CLEAN. `h3` is the number of remaining CLEAN actions plus Manhattan distance to the closest dirty cell plus a Manhattan minimum spanning tree across all dirty cells.


