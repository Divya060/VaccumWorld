"""
    python experiments.py                 # full run, 60s timeout per config
    python experiments.py --quick         # small grids only, for a fast check
    python experiments.py --timeout 120   # be more patient
    python experiments.py --grids g5_rooms g6_corridor

"""

import argparse
import csv
import multiprocessing as mp
import queue as queue_mod
import sys
import time

from test_grids import GRIDS, EXAMPLE, parse_grid

# Every combination the harness will try.
ALGORITHMS = ['dfs', 'astar', 'idastar']
HEURISTIC_NAMES = ['h0', 'h1', 'h2', 'h3']

# DFS ignores the heuristic, so it is run once per grid with this label.
NO_HEURISTIC = '-'

QUICK_GRIDS = ['g1_tiny', 'g2_open', 'g3_blocks']

CSV_FIELDS = [
    'grid', 'rows', 'cols', 'n_dirty',
    'algorithm', 'heuristic', 'status',
    'cost', 'nodes_expanded', 'max_frontier', 'iterations', 'seconds',
]


# ---------------------------------------------------------------------------
# Running one configuration
# ---------------------------------------------------------------------------

def build_problem(grid_name):
    """Construct a VacuumWorld for a named grid."""
    from vacuum_world import VacuumWorld
    art = EXAMPLE if grid_name == 'example' else GRIDS[grid_name]
    grid, start, dirty = parse_grid(art)
    return VacuumWorld(grid, start, dirty)


def run_single(algorithm, grid_name, heuristic_name):
    """Run one configuration and return a result dict. Runs in a subprocess."""
    from search import dfs_search, astar_search, idastar_search
    from heuristics import HEURISTICS

    problem = build_problem(grid_name)
    started = time.perf_counter()

    if algorithm == 'dfs':
        plan, expanded, frontier = dfs_search(problem)
        iterations = None
    elif algorithm == 'astar':
        plan, expanded, frontier = astar_search(problem, HEURISTICS[heuristic_name])
        iterations = None
    elif algorithm == 'idastar':
        plan, expanded, iterations = idastar_search(problem, HEURISTICS[heuristic_name])
        frontier = None
    else:
        raise ValueError("unknown algorithm: %s" % algorithm)

    elapsed = time.perf_counter() - started

    return {
        'status': 'ok',
        'cost': None if plan is None else len(plan),
        'nodes_expanded': expanded,
        'max_frontier': frontier,
        'iterations': iterations,
        'seconds': round(elapsed, 4),
    }


def _worker(out, algorithm, grid_name, heuristic_name):
    """Subprocess entry point. Puts (status, payload) on the queue."""
    sys.setrecursionlimit(100000)
    try:
        out.put(('ok', run_single(algorithm, grid_name, heuristic_name)))
    except NotImplementedError as exc:
        out.put(('skip', str(exc)))
    except Exception as exc:  # noqa: BLE001 - report anything the student hits
        out.put(('error', '%s: %s' % (type(exc).__name__, exc)))


def run_with_timeout(algorithm, grid_name, heuristic_name, timeout):
    """Run one configuration in a subprocess, killing it after `timeout` seconds."""
    out = mp.Queue()
    proc = mp.Process(target=_worker,
                      args=(out, algorithm, grid_name, heuristic_name))
    started = time.perf_counter()
    proc.start()
    try:
        status, payload = out.get(timeout=timeout)
    except queue_mod.Empty:
        status, payload = 'timeout', None
    finally:
        if proc.is_alive():
            proc.terminate()
        proc.join()

    elapsed = round(time.perf_counter() - started, 4)

    if status == 'ok':
        return payload
    if status == 'timeout':
        return {'status': 'TIMEOUT', 'cost': None, 'nodes_expanded': None,
                'max_frontier': None, 'iterations': None, 'seconds': elapsed}
    if status == 'skip':
        return {'status': 'SKIP', 'cost': None, 'nodes_expanded': None,
                'max_frontier': None, 'iterations': None, 'seconds': None}
    return {'status': 'ERROR (%s)' % payload, 'cost': None,
            'nodes_expanded': None, 'max_frontier': None,
            'iterations': None, 'seconds': elapsed}


# ---------------------------------------------------------------------------
# The full sweep
# ---------------------------------------------------------------------------

def configurations(grid_names):
    """Yield (algorithm, grid, heuristic) triples to measure."""
    for grid_name in grid_names:
        yield ('dfs', grid_name, NO_HEURISTIC)
        for algorithm in ('astar', 'idastar'):
            for heuristic_name in HEURISTIC_NAMES:
                yield (algorithm, grid_name, heuristic_name)


def sweep(grid_names, timeout, out_path='results.csv'):
    """Run every configuration and write results.csv. Returns the rows."""
    rows = []
    print("%-13s %-8s %-4s %-10s %s" % (
        'grid', 'algo', 'h', 'status', 'nodes / cost / time'))
    print('-' * 68)

    for algorithm, grid_name, heuristic_name in configurations(grid_names):
        problem_art = EXAMPLE if grid_name == 'example' else GRIDS[grid_name]
        grid, _, dirty = parse_grid(problem_art)

        result = run_with_timeout(algorithm, grid_name, heuristic_name, timeout)
        row = {
            'grid': grid_name,
            'rows': len(grid),
            'cols': len(grid[0]),
            'n_dirty': len(dirty),
            'algorithm': algorithm,
            'heuristic': heuristic_name,
        }
        row.update(result)
        rows.append(row)

        if result['status'] == 'ok':
            detail = "%s nodes, cost %s, %.2fs" % (
                result['nodes_expanded'], result['cost'], result['seconds'])
        else:
            detail = ''
        print("%-13s %-8s %-4s %-10s %s" % (
            grid_name, algorithm, heuristic_name, result['status'], detail))

    with open(out_path, 'w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in CSV_FIELDS})

    print('-' * 68)
    print("wrote %d rows to %s" % (len(rows), out_path))
    return rows


# ---------------------------------------------------------------------------
# YOUR WORK STARTS HERE
# ---------------------------------------------------------------------------

def make_table(rows):
    """Write summary.csv: one row per grid, nodes expanded per configuration.

    Each cell is the number of nodes expanded, or TIMEOUT / ERROR. The
    optimal cost comes from any A* run that finished.
    """
    import csv
    configs = [('dfs', '-')] + [(a, h) for a in ('astar', 'idastar')
                                for h in HEURISTIC_NAMES]
    header = ['grid', 'n_dirty', 'optimal_cost', 'dfs_cost'] + [
        'dfs_nodes' if a == 'dfs' else '%s_%s_nodes' % (a, h)
        for a, h in configs]
    grids = list(dict.fromkeys(r['grid'] for r in rows))
    table = []
    for grid in grids:
        mine = [r for r in rows if r['grid'] == grid]
        lookup = {(r['algorithm'], r['heuristic']): r for r in mine}
        optimal = next((r['cost'] for r in mine if r['algorithm'] == 'astar'
                        and r['status'] == 'ok'), '')
        dfs = lookup.get(('dfs', '-'), {})
        line = [grid, mine[0]['n_dirty'], optimal, dfs.get('cost', '')]
        for key in configs:
            r = lookup.get(key)
            if r is None:
                line.append('')
            elif r['status'] == 'ok':
                line.append(r['nodes_expanded'])
            else:
                line.append(r['status'])
        table.append(line)
    with open('summary.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)
        writer.writerows(table)

    widths = [max(len(str(x)) for x in col) for col in zip(header, *table)]
    print()
    for line in [header] + table:
        print('  '.join(str(x).rjust(w) for x, w in zip(line, widths)))
    print("\nwrote summary.csv")
    return table


def _timeout_marker_level(rows):
    """A y-value above every finished run, where TIMEOUTs are drawn."""
    finished = [int(r['nodes_expanded']) for r in rows
                if r['status'] == 'ok' and r['nodes_expanded'] not in ('', None)]
    return max(finished) * 4 if finished else 1


def plot_scaling(rows):
    """figures/scaling.png: nodes expanded vs. number of dirty cells.

    DFS, A*/h2 and IDA*/h2, one point per grid. Runs that hit the timeout
    are not dropped: they are drawn as an X on a dashed TIMEOUT line above
    every finished run, so the reader sees where each algorithm gave out.
    """
    import os
    import matplotlib.pyplot as plt
    os.makedirs('figures', exist_ok=True)
    ceiling = _timeout_marker_level(rows)
    series = [('dfs', NO_HEURISTIC, 'DFS'),
              ('astar', 'h2', 'A* (h2)'),
              ('idastar', 'h2', 'IDA* (h2)')]
    fig, ax = plt.subplots(figsize=(9, 5))
    for algorithm, heuristic, label in series:
        selected = sorted((r for r in rows if r['algorithm'] == algorithm
                           and r['heuristic'] == heuristic),
                          key=lambda r: (int(r['n_dirty']), r['grid']))
        ok = [r for r in selected if r['status'] == 'ok']
        line, = ax.plot([int(r['n_dirty']) for r in ok],
                        [int(r['nodes_expanded']) for r in ok],
                        'o-', label=label)
        timed_out = [r for r in selected if r['status'] != 'ok']
        if timed_out:
            ax.plot([int(r['n_dirty']) for r in timed_out],
                    [ceiling] * len(timed_out), 'x', color=line.get_color(),
                    markersize=11, markeredgewidth=2.5)
            for r in timed_out:
                ax.annotate('%s %s' % (label, r['grid']),
                            (int(r['n_dirty']), ceiling),
                            textcoords='offset points', xytext=(-8, -16),
                            ha='right', fontsize=8, color=line.get_color())
    ax.axhline(ceiling, linestyle='--', color='grey', linewidth=1)
    ax.text(ax.get_xlim()[0], ceiling, ' TIMEOUT', va='bottom',
            fontsize=8, color='grey')
    ax.set_yscale('log')
    ax.set_xlabel('Number of dirty cells (one point per grid)')
    ax.set_ylabel('Nodes expanded (log scale)')
    ax.set_title('Search effort vs. number of dirty cells')
    ax.legend(loc='upper center')
    fig.tight_layout()
    fig.savefig('figures/scaling.png', dpi=170)
    plt.close(fig)


def plot_heuristics(rows):
    """figures/heuristics.png: nodes expanded by h0-h3, A* and IDA* side by side.

    One group of bars per grid. A configuration that hit the timeout is
    drawn as a hatched bar reaching the TIMEOUT line and labelled, rather
    than left out.
    """
    import os
    import matplotlib.pyplot as plt
    os.makedirs('figures', exist_ok=True)
    grids = list(dict.fromkeys(r['grid'] for r in rows))
    ceiling = _timeout_marker_level(rows)
    width = 0.8 / len(HEURISTIC_NAMES)
    fig, axes = plt.subplots(1, 2, figsize=(13, 5), sharey=True)
    for ax, algorithm, title in ((axes[0], 'astar', 'A*'),
                                 (axes[1], 'idastar', 'IDA*')):
        for i, h in enumerate(HEURISTIC_NAMES):
            offset = (i - (len(HEURISTIC_NAMES) - 1) / 2) * width
            for j, grid in enumerate(grids):
                r = next((r for r in rows if r['grid'] == grid and
                          r['algorithm'] == algorithm and
                          r['heuristic'] == h), None)
                if r is None:
                    continue
                color = 'C%d' % i
                if r['status'] == 'ok':
                    ax.bar(j + offset, int(r['nodes_expanded']), width,
                           color=color, label=h if j == 0 else None)
                else:
                    ax.bar(j + offset, ceiling, width, color='white',
                           edgecolor=color, hatch='///',
                           label=h if j == 0 else None)
                    ax.text(j + offset, ceiling, 'T/O', ha='center',
                            va='bottom', fontsize=7, color=color)
        ax.axhline(ceiling, linestyle='--', color='grey', linewidth=1)
        ax.set_xticks(range(len(grids)))
        ax.set_xticklabels(grids, rotation=25, ha='right')
        ax.set_yscale('log')
        ax.set_title('%s: nodes expanded by heuristic' % title)
    axes[0].set_ylabel('Nodes expanded (log scale)')
    axes[1].legend(title='heuristic', loc='upper left')
    fig.text(0.5, 0.005, 'Hatched bars marked T/O hit the per-configuration '
             'timeout; they are not real node counts.', ha='center',
             fontsize=8, color='grey')
    fig.tight_layout(rect=(0, 0.03, 1, 1))
    fig.savefig('figures/heuristics.png', dpi=170)
    plt.close(fig)


# ---------------------------------------------------------------------------

def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split('\n')[2])
    parser.add_argument('--timeout', type=float, default=60.0,
                        help="seconds per configuration (default: 60)")
    parser.add_argument('--quick', action='store_true',
                        help="only the three smallest grids")
    parser.add_argument('--grids', nargs='+', metavar='NAME',
                        help="specific grids to run (default: all six)")
    parser.add_argument('--out', default='results.csv',
                        help="where to write the raw results")
    parser.add_argument('--analyze', action='store_true',
                        help="also run your table and plot functions")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    if args.grids:
        grid_names = args.grids
    elif args.quick:
        grid_names = QUICK_GRIDS
    else:
        grid_names = list(GRIDS)

    unknown = [g for g in grid_names if g != 'example' and g not in GRIDS]
    if unknown:
        print("unknown grid(s): %s" % ', '.join(unknown))
        print("available: example, %s" % ', '.join(GRIDS))
        return 2

    rows = sweep(grid_names, args.timeout, args.out)

    if args.analyze:
        make_table(rows)
        plot_scaling(rows)
        plot_heuristics(rows)

    return 0


if __name__ == "__main__":
    # The multiprocessing guard above is required on Windows and macOS.
    sys.exit(main())
